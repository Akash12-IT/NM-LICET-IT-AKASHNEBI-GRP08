export const WEBSITE_BASE_URL = 'https://rabbitmart-cm.vercel.app'
export const PRODUCTS_BASEURL = 'https://rabbitmart-products.vercel.app/products'
export const ORDERS_BASEURL = 'https://rabbitmart-orders.vercel.app/orders'
export const USER_BASEURL = 'https://rabbitmart-users.vercel.app/me'