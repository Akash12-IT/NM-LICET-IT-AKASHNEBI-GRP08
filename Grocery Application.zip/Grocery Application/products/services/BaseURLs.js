export const PRODUCTS_BASEURL = 'https://rabbitmart-products.vercel.app/products'
export const USER_BASEURL = 'https://rabbitmart-users.vercel.app/me'